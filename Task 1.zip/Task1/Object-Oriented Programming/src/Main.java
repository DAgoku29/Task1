class Car {
    private String make;
    private String model;

    public Car(String make, String model) {
        this.make = make;
        this.model = model;
    }

    public void start()
    {
            System.out.println("Starting the "+ make + " " + model);//The make variable is a string that stores the make of the car. In this case, the value of the make variable is "Toyota".
                                                                    //The model variable is a string that stores the model of the car. In this case, the value of the model variable is "Camry".
    }

    public void stop() // Create a method called stop for printing statement "stopping" string.
    {
        System.out.println("Stopping the "  + make +  " "  + model);
    }
}

public class Main {
    public static void main(String[] args) {
        Car car = new Car("Toyota", "Camry");
        car.start();
        car.stop();
    }
}