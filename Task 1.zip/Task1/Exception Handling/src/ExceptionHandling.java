public class ExceptionHandling {
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5};

        try {
            System.out.println(numbers[3]);// The index value should be less than 5.
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Array index out of bounds.");
        }
        try {
            int result = divide(4, 2);
            System.out.println("Result: " + result);
        }   catch(ArithmeticException e){
            System.out.println("Division by zero is not allowed.");//In this case, the catch block is catching an ArithmeticException exception. This exception is thrown when a division is attempted by zero. The catch block prints a message to the console stating that division by zero is not allowed.
        }
    }

    public static int divide(int a, int b) {
        if(b == 0){
            throw new ArithmeticException("Division by zero is not allowed.");//f statement that checks if the value of the b variable is equal to zero. If it is, the throw statement is executed.
        }
        return a / b;
    }
}