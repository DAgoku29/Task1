
public class ArrayManipulation {
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5};

        for (int i = 0; i < numbers.length; i++) { //There will be no "=" after "<" to print the array.The condition is checked before each iteration of the loop.
            System.out.println(numbers[i]);
        }
    }
}